#!/bin/bash

echo "running ../ModelagemFletcher.exe TTI 248 248 248 16 12.5 12.5 12.5 0.001 1.0 | tee log.txt"
time ../ModelagemFletcher.exe TTI 248 248 248 16 12.5 12.5 12.5 0.001 1.0 | tee log.txt

