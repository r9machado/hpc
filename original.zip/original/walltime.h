#ifdef __cplusplus
extern "C" {
#endif

double wtime();

#ifdef __cplusplus
}
#endif
